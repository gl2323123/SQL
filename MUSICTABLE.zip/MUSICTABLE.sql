CREATE TABLE IF NOT EXISTS Musicain (
id SERIAL PRIMARY KEY,
name VARCHAR(50) NOT NULL
);
CREATE TABLE IF NOT EXISTS Genre (
id SERIAL PRIMARY KEY,
name VARCHAR(50) NOT NULL
);
CREATE TABLE IF NOT EXISTS GenresMusicain (
id SERIAL PRIMARY KEY,
musicain_id INT NOT NULL references Musicain(id),
genre_id INT NOT NULL references Genre(id)
);

CREATE TABLE IF NOT EXISTS Album (
id SERIAL PRIMARY KEY,
name VARCHAR(50) NOT NULL,
year_of_realese DECIMAL(4,0) NOT NULL 
);

CREATE TABLE IF NOT exists MusicainAlbum (
id SERIAL PRIMARY KEY,
musicain_id INT NOT NULL references Musicain(id),
album_id INT NOT NULL references Album(id)
);

CREATE TABLE IF NOT exists Track(
id SERIAL PRIMARY KEY,
name VARCHAR(40) not null,
album_id INT NOT NULL REFERENCES Album(id),
times INT NOT NULL
);


CREATE TABLE IF NOT EXISTS Collection (
id SERIAL PRIMARY KEY,
name varchar(40) NOT NULL,
year_of_relase decimal(4,0)
);

CREATE TABLE IF NOT EXISTS CollectionTrack (
id SERIAL PRIMARY KEY,
collection_id INT NOT NULL references Collection(id),
track_id INT NOT NULL REFERENCES track(id)
);






INSERT INTO musicain
VALUES (1, 'Metalica');

INSERT INTO musicain
VALUES (2, 'AC/DC');

INSERT INTO musicain
VALUES (3, 'Nirvana');

INSERT INTO musicain
VALUES (4, 'Blur');

INSERT INTO musicain
VALUES (5, 'DJ SMASH');



INSERT INTO genre 
VALUES (1, 'Pop');

INSERT INTO genre 
VALUES (2, 'Punk-Rock');

INSERT INTO genre 
VALUES (3, 'Rock');


INSERT INTO genresmusicain  
VALUES (1,1, 3);

INSERT INTO genresmusicain  
VALUES (2,1, 1);

INSERT INTO genresmusicain  
VALUES (3,2, 3);

INSERT INTO genresmusicain  
VALUES (4,2, 2);

INSERT INTO genresmusicain  
VALUES (5,3, 3);

INSERT INTO genresmusicain  
VALUES (6,4, 3);

INSERT INTO genresmusicain  
VALUES (7,5, 1);



INSERT INTO album  
VALUES (1,'In Utero', 1993);

INSERT INTO album  
VALUES (2,'Highway To Hell',1979 );

INSERT INTO album  
VALUES (3,'Moscow',2020 );


INSERT INTO album  
VALUES (4,'Load',2009 );


INSERT INTO musicainalbum  
VALUES (1,1,3);

INSERT INTO musicainalbum  
VALUES (2,5,4);

INSERT INTO musicainalbum  
VALUES (3,2,2);

INSERT INTO musicainalbum  
VALUES (4,3,1);

INSERT INTO track  
VALUES (1,'Moscow never sleep', 3, 183
);

INSERT INTO track  
VALUES (2,'Rape me', 1, 204
);

INSERT INTO track  
VALUES (3,'Lithium', 1, 258
);